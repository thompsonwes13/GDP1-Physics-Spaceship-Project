BUILD and RUN in Release x64

Controls:

WASD: Move Player
WASD + SHIFT: Run
F: Shoot Laser
R: Shoot Rocket